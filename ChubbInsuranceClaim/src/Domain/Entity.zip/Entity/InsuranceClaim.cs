﻿using ChubbInsuranceClaim.src.Domain.Common;
using ChubbInsuranceClaim.src.Domain.Enums;

namespace ChubbInsuranceClaim.src.Domain.Entity
{
    public class InsuranceClaim : AuditableEntity
    {
        public string ClaimNumber { get; set; } = string.Empty;

        public Guid IncidentId { get; set; }

        public Incident Incident { get; set; } = null!;

        public Guid CustomerId { get; set; }

        public BusinessUser Customer { get; set; } = null!;

        public Guid? AssignedOfficerId { get; set; }

        public BusinessUser? AssignedOfficer { get; set; }

        public string Title { get; set; } = string.Empty;

        public string Description { get; set; } = string.Empty;

        public decimal ClaimAmount { get; set; }

        public decimal? ApprovedAmount { get; set; }

        public ClaimStatus Status { get; set; }

        public DateTime SubmittedDate { get; set; }

        public DateTime? ClosedDate { get; set; }

        // Navigation

        public ICollection<ClaimDocument> Documents
            = new List<ClaimDocument>();

        public ICollection<ClaimNote> Notes
            = new List<ClaimNote>();

        public ICollection<ClaimAssignment> Assignments
            = new List<ClaimAssignment>();

        public ICollection<ClaimTimeline> Timeline
            = new List<ClaimTimeline>();

        public ICollection<ClaimStatusHistory> StatusHistory
            = new List<ClaimStatusHistory>();
    }
}
