﻿using ChubbInsuranceClaim.src.Domain.Common;
using ChubbInsuranceClaim.src.Domain.Enums;

namespace ChubbInsuranceClaim.src.Domain.Entity
{
    public class ClaimStatusHistory : AuditableEntity
    {
        public Guid ClaimId { get; set; }

        public InsuranceClaim Claim { get; set; } = null!;

        public ClaimStatus OldStatus { get; set; }

        public ClaimStatus NewStatus { get; set; }

        public Guid ChangedById { get; set; }

        public BusinessUser ChangedBy { get; set; } = null!;

        public string Remarks { get; set; } = string.Empty;
    }
}
