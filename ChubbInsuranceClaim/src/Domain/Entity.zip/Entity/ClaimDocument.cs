﻿using ChubbInsuranceClaim.src.Domain.Common;
using ChubbInsuranceClaim.src.Domain.Enums;

namespace ChubbInsuranceClaim.src.Domain.Entity
{
    public class ClaimDocument : AuditableEntity
    {
        public Guid ClaimId { get; set; }

        public InsuranceClaim Claim { get; set; } = null!;

        public string FileName { get; set; } = string.Empty;

        public string OriginalFileName { get; set; } = string.Empty;

        public string ContentType { get; set; } = string.Empty;

        public long FileSize { get; set; }

        public Guid UploadedById { get; set; }

        public BusinessUser UploadedBy { get; set; } = null!;
    }
}
