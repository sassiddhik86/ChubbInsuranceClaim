﻿using ChubbInsuranceClaim.src.Domain.Common;
using ChubbInsuranceClaim.src.Domain.Enums;

namespace ChubbInsuranceClaim.src.Domain.Entity
{
    public class Incident : AuditableEntity
    {
        public string IncidentNumber { get; set; } = string.Empty;

        public DateTime IncidentDate { get; set; }

        public IncidentType IncidentType { get; set; }

        public string Location { get; set; } = string.Empty;

        public string Description { get; set; } = string.Empty;

        public string? PoliceReportNumber { get; set; }

        public Guid CustomerId { get; set; }

        public BusinessUser Customer { get; set; } = null!;

        public ICollection<InsuranceClaim> Claims
            = new List<InsuranceClaim>();
    }
}
