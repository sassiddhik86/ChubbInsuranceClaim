﻿using ChubbInsuranceClaim.src.Domain.Common;

namespace ChubbInsuranceClaim.src.Domain.Entity
{
    public class BusinessRole : AuditableEntity
    {
        public string Name { get; set; } = string.Empty;

        public string Description { get; set; } = string.Empty;

        public bool IsSystemRole { get; set; }

        // Navigation

        public ICollection<BusinessUser> Users { get; set; }
            = new List<BusinessUser>();
    }
}
