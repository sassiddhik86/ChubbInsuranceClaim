﻿using ChubbInsuranceClaim.src.Domain.Common;

namespace ChubbInsuranceClaim.src.Domain.Entity
{
    public class ClaimAssignment : AuditableEntity
    {
        public Guid ClaimId { get; set; }

        public InsuranceClaim Claim { get; set; } = null!;

        public Guid AssignedToId { get; set; }

        public BusinessUser AssignedTo { get; set; } = null!;

        public Guid AssignedById { get; set; }

        public BusinessUser AssignedBy { get; set; } = null!;

        public DateTime AssignedDate { get; set; }

        public string Remarks { get; set; } = string.Empty;
    }
}
