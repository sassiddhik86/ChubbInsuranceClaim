﻿using ChubbInsuranceClaim.src.Domain.Common;
using ChubbInsuranceClaim.src.Domain.Enums;

namespace ChubbInsuranceClaim.src.Domain.Entity
{
    public class BusinessUser : AuditableEntity
    {
        public string EmployeeNumber { get; set; } = string.Empty;

        public string Username { get; set; } = string.Empty;

        public string PasswordHash { get; set; } = string.Empty;

        public string Email { get; set; } = string.Empty;

        public string FirstName { get; set; } = string.Empty;

        public string LastName { get; set; } = string.Empty;

        public string PhoneNumber { get; set; } = string.Empty;

        public UserStatus Status { get; set; }

        public DateTime? LastLogin { get; set; }

        public Guid RoleId { get; set; }

        public BusinessRole Role { get; set; } = null!;

        public Guid DepartmentId { get; set; }

        public Department Department { get; set; } = null!;

        public Guid TeamId { get; set; }

        public Team Team { get; set; } = null!;

        // Navigation

        public ICollection<Incident> Incidents
            = new List<Incident>();

        public ICollection<InsuranceClaim> CustomerClaims
            = new List<InsuranceClaim>();

        public ICollection<InsuranceClaim> AssignedClaims
            = new List<InsuranceClaim>();

        public ICollection<RefreshToken> RefreshTokens
            = new List<RefreshToken>();

        public ICollection<Notification> Notifications
            = new List<Notification>();
    }
}
